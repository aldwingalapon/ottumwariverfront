<?php
/**
 * Image Comparison wrap end template
 */
?>
</div>
