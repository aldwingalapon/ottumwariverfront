<?php
/**
 * Price list template
 */
?>

<?php $this->__get_global_looped_template( 'price-list', 'price_list' ); ?>